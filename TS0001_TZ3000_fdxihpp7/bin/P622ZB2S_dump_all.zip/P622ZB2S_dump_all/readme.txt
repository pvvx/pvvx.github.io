A dump of all data from the P622ZB2S module, which contains the firmware for a Zigbee router (smart switch).
For analyzing ROM code using AI and Ghidra.