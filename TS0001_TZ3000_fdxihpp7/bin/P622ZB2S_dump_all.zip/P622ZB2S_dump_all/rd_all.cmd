python3 rdwr_phy62x2.py -p COM11 -b 1000000 rc 0x11000000 0x80000 flash_11000000_80000.bin
python3 rdwr_phy62x2.py -n -p COM11 -b 1000000 rc 0x10000000 0x20000 rom_10000000_20000.bin
python3 rdwr_phy62x2.py -n -p COM11 -b 1000000 rc 0x1fff0000 0x10000 ram_1fff0000_10000.bin
python3 rdwr_phy62x2.py -n -p COM11 -b 1000000 rc 0x40000000 0x10000 reg_40000000_10000.bin